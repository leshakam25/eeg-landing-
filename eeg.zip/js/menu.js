$(document).ready(function () {
  $(".togler").click(function () {
    $(".togler").toggleClass("open-menu");
    $(".header-menu").toggleClass("open-menu");
  });
  $(".production-togler").click(function () {
    $(".production-menu").toggleClass("open-menu");
  });
  $(".close-icon").click(function () {
    $(".production-menu").removeClass("open-menu");
  });
  $(".production-togler2").click(function () {
    $(".production-menu2").toggleClass("open-menu");
  });
  $(".close-icon2").click(function () {
    $(".production-menu2").removeClass("open-menu");
  });
  $(".production-togler3").click(function () {
    $(".production-menu3").toggleClass("open-menu");
  });
  $(".close-icon3").click(function () {
    $(".production-menu3").removeClass("open-menu");
  });
  $(".production-togler4").click(function () {
    $(".production-menu4").toggleClass("open-menu");
  });
  $(".close-icon4").click(function () {
    $(".production-menu4").removeClass("open-menu");
  });
  $(".production-togler5").click(function () {
    $(".production-menu5").toggleClass("open-menu");
  });
  $(".close-icon5").click(function () {
    $(".production-menu5").removeClass("open-menu");
  });
  $(".production-togler6").click(function () {
    $(".production-menu6").toggleClass("open-menu");
  });
  $(".close-icon6").click(function () {
    $(".production-menu6").removeClass("open-menu");
  });
});
